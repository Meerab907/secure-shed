import 'package:cloud_firestore/cloud_firestore.dart';

class TaskModel {
  String taskId;
  String userId;
  String title;
  String description;
  String category;
  String location;

  DateTime date;
  DateTime startTime;
  DateTime endTime;

  String notes;
  String priority;
  String status;

  DateTime createdAt;
  DateTime updatedAt;

  TaskModel({
    required this.taskId,
    required this.userId,
    required this.title,
    required this.description,
    required this.category,
    required this.location,
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.notes,
    required this.priority,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  // ✅ SAFE PARSER (FIXES YOUR CRASH)
  static DateTime _safeDate(dynamic value) {
    if (value == null) return DateTime.now();

    if (value is Timestamp) return value.toDate();

    if (value is String) {
      return DateTime.tryParse(value) ?? DateTime.now();
    }

    return DateTime.now();
  }

  factory TaskModel.fromMap(Map<String, dynamic> map) {
    return TaskModel(
      taskId: map['taskId'] ?? '',
      userId: map['userId'] ?? '',
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      category: map['category'] ?? '',
      location: map['location'] ?? '',

      date: _safeDate(map['date']),
      startTime: _safeDate(map['startTime']),
      endTime: _safeDate(map['endTime']),

      notes: map['notes'] ?? '',
      priority: map['priority'] ?? 'Medium',
      status: map['status'] ?? 'Pending',

      createdAt: _safeDate(map['createdAt']),
      updatedAt: _safeDate(map['updatedAt']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'taskId': taskId,
      'userId': userId,
      'title': title,
      'description': description,
      'category': category,
      'location': location,

      'date': Timestamp.fromDate(date),
      'startTime': Timestamp.fromDate(startTime),
      'endTime': Timestamp.fromDate(endTime),

      'notes': notes,
      'priority': priority,
      'status': status,

      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }
}