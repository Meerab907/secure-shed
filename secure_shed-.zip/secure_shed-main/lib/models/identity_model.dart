class IdentityModel {
  final String userId;

  final String fullName;
  final String cnic;
  final String phone;
  final String address;
  final String jobTitle;

  final String selfieImagePath;
  final String cnicFrontPath;
  final String cnicBackPath;

  final DateTime createdAt;

  IdentityModel({
    required this.userId,
    required this.fullName,
    required this.cnic,
    required this.phone,
    required this.address,
    required this.jobTitle,
    required this.selfieImagePath,
    required this.cnicFrontPath,
    required this.cnicBackPath,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'fullName': fullName,
      'cnic': cnic,
      'phone': phone,
      'address': address,
      'jobTitle': jobTitle,
      'selfieImagePath': selfieImagePath,
      'cnicFrontPath': cnicFrontPath,
      'cnicBackPath': cnicBackPath,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory IdentityModel.fromMap(
      Map<String, dynamic> map) {
    return IdentityModel(
      userId: map['userId'],
      fullName: map['fullName'],
      cnic: map['cnic'],
      phone: map['phone'],
      address: map['address'],
      jobTitle: map['jobTitle'],
      selfieImagePath: map['selfieImagePath'],
      cnicFrontPath: map['cnicFrontPath'],
      cnicBackPath: map['cnicBackPath'],
      createdAt: DateTime.parse(map['createdAt']),
    );
  }
}