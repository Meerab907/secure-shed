class AppUser {
  final String uid;
  final String username;
  final String email;

  final String pinHash;

  final bool pinEnabled;
  final bool biometricEnabled;

  AppUser({
    required this.uid,
    required this.username,
    required this.email,
    required this.pinHash,
    required this.pinEnabled,
    required this.biometricEnabled,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'username': username,
      'email': email,
      'pinHash': pinHash,
      'pinEnabled': pinEnabled,
      'biometricEnabled': biometricEnabled,
    };
  }

  factory AppUser.fromMap(Map<String, dynamic> map) {
    return AppUser(
      uid: map['uid'],
      username: map['username'],
      email: map['email'],
      pinHash: map['pinHash'],
      pinEnabled: map['pinEnabled'],
      biometricEnabled: map['biometricEnabled'],
    );
  }
}