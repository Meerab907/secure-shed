import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocalSecurityStorage {

  // GET APP DIRECTORY
  static Future<String> _getDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = Directory("${dir.path}/security");
    if (!await path.exists()) {
      await path.create(recursive: true);
    }
    return path.path;
  }

  // SAVE IMAGE (FACE / FINGERPRINT)
  static Future<String> saveImage(File image, String name) async {
    final dir = await _getDir();
    final file = File("$dir/$name.jpg");

    await file.writeAsBytes(await image.readAsBytes());
    return file.path;
  }

  // SAVE PIN
  static Future<void> savePin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString("user_pin", pin);
  }

  static Future<String?> getPin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("user_pin");
  }

  // SAVE FLAGS
  static Future<void> setBiometricEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("bio_enabled", value);
  }

  static Future<bool> isBiometricEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool("bio_enabled") ?? false;
  }
}