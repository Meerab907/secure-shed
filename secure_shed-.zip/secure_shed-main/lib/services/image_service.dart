import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

class ImageService {
  final ImagePicker _picker = ImagePicker();

  Future<String?> captureAndSaveImage() async {
    final pickedFile = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 70,
    );

    if (pickedFile == null) return null;

    final directory =
        await getApplicationDocumentsDirectory();

    final imageName =
        DateTime.now().millisecondsSinceEpoch.toString();

    final savedImage = await File(
      pickedFile.path,
    ).copy(
      '${directory.path}/$imageName.jpg',
    );

    return savedImage.path;
  }
}