import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/identity_model.dart';

class IdentityService {
  final FirebaseFirestore _firestore =
      FirebaseFirestore.instance;

  Future<void> saveIdentity(
      IdentityModel identity) async {
    await _firestore
        .collection('identity_verifications')
        .doc(identity.userId)
        .set(identity.toMap());
  }
}