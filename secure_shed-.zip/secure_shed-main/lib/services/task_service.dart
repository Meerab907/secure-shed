import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/task_model.dart';

class TaskService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // ✅ SAFE UID (prevents crash)
  String? get uid => _auth.currentUser?.uid;

  // CREATE TASK
  Future<void> createTask(TaskModel task) async {
    await _firestore
        .collection('tasks')
        .doc(task.taskId)
        .set(task.toMap());
  }

  // GET TASKS (SAFE)
  Stream<List<TaskModel>> getTasks({String? category}) {
    final userId = uid;

    if (userId == null) {
      return const Stream.empty();
    }

    Query query = _firestore
        .collection('tasks')
        .where('userId', isEqualTo: userId);

    if (category != null && category != "All") {
      query = query.where('category', isEqualTo: category);
    }

    return query.snapshots().map((snapshot) {
      return snapshot.docs
          .map((doc) =>
              TaskModel.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    });
  }

  // TODAY TASKS
  Stream<List<TaskModel>> getTodayTasks() {
    final userId = uid;

    if (userId == null) {
      return const Stream.empty();
    }

    final today = DateTime.now();

    return _firestore
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) =>
              TaskModel.fromMap(doc.data() as Map<String, dynamic>))
          .where((task) =>
              task.date.year == today.year &&
              task.date.month == today.month &&
              task.date.day == today.day)
          .toList();
    });
  }

  // GET ONCE
  Future<List<TaskModel>> getTasksOnce() async {
    final userId = uid;

    if (userId == null) return [];

    final snapshot = await _firestore
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .get();

    return snapshot.docs
        .map((doc) =>
            TaskModel.fromMap(doc.data() as Map<String, dynamic>))
        .toList();
  }

  // DELETE
  Future<void> deleteTask(String taskId) async {
    await _firestore.collection('tasks').doc(taskId).delete();
  }

  // UPDATE FULL TASK
  Future<void> updateTask(TaskModel task) async {
    await _firestore
        .collection('tasks')
        .doc(task.taskId)
        .update(task.toMap());
  }

  // UPDATE STATUS
  Future<void> updateTaskStatus(String taskId, String status) async {
    await _firestore.collection('tasks').doc(taskId).update({
      'status': status,
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
  }

  // CONFLICT CHECK
  bool hasTimeConflict(TaskModel newTask, List<TaskModel> tasks) {
    for (final task in tasks) {
      final overlap = newTask.startTime.isBefore(task.endTime) &&
          newTask.endTime.isAfter(task.startTime);

      if (overlap) return true;
    }
    return false;
  }
}