import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'utils/app_theme.dart';
import 'firebase_options.dart';
import 'utils/routes.dart';

import 'services/notification_service.dart';

// Screens
import 'screens/loading_screen.dart';
import 'screens/get_started_screen.dart';
import 'screens/intro_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/forgot_password_screen.dart';
import 'screens/verification_code_screen.dart';
import 'screens/reset_password_screen.dart';

import 'screens/identity_step1_screen.dart';
import 'screens/identity_step2_screen.dart';
import 'screens/identity_step3_screen.dart';
import 'screens/identity_step4_screen.dart';
import 'screens/identity_step5_screen.dart';

import 'screens/security_intro_screen.dart';
import 'screens/face_screen.dart';
import 'screens/fingerprint_screen.dart';
import 'screens/pin_screen.dart';

import 'screens/home_screen.dart';
import 'screens/calendar_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/edit_profile_screen.dart';

import 'screens/create_task_screen.dart';
import 'screens/display_task_screen.dart';
import 'screens/reschedule_task_screen.dart';
import 'screens/add_meeting_screen.dart';

import 'screens/category_screen.dart';
import 'screens/today_tasks_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // IMPORTANT: notification init AFTER Firebase
  await NotificationService.init();

  runApp(const SecureShedApp());
}

class SecureShedApp extends StatelessWidget {
  const SecureShedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: AppRoutes.loading,
      theme: AppTheme.lightTheme,
      routes: {
        AppRoutes.loading: (context) => const LoadingScreen(),
        AppRoutes.getStarted: (context) => const GetStartedScreen(),
        AppRoutes.intro: (context) => const IntroScreen(),
        AppRoutes.login: (context) => const LoginScreen(),
        AppRoutes.signup: (context) => const SignupScreen(),
        AppRoutes.forgotPassword: (context) => const ForgotPasswordScreen(),
        AppRoutes.verificationCode: (context) => const VerificationCodeScreen(),
        AppRoutes.resetPassword: (context) => const ResetPasswordScreen(),
        AppRoutes.identity1: (context) => const IdentityStep1Screen(),
        AppRoutes.identity2: (context) => const IdentityStep2Screen(),
        AppRoutes.identity3: (context) => const IdentityStep3Screen(),
        AppRoutes.identity4: (context) => const IdentityStep4Screen(),
        AppRoutes.identity5: (context) => const IdentityStep5Screen(),
        AppRoutes.securityIntro: (context) => const SecurityIntroScreen(),
        AppRoutes.face: (context) => const FaceScreen(),
        AppRoutes.fingerprint: (context) => const FingerprintScreen(),
        AppRoutes.pin: (context) => const PinScreen(),
        AppRoutes.home: (context) => const HomeScreen(),
        AppRoutes.calendar: (context) => const CalendarScreen(),
        AppRoutes.profile: (context) => ProfileScreen(),
        AppRoutes.settings: (context) => const SettingsScreen(),
        AppRoutes.editProfile: (context) => const EditProfileScreen(),
        AppRoutes.createTask: (context) => const CreateTaskScreen(),
        AppRoutes.displayTask: (context) => const DisplayTaskScreen(),
        AppRoutes.reschedule: (context) => const RescheduleTaskScreen(),
        AppRoutes.addMeeting: (context) => const AddMeetingScreen(),
        AppRoutes.todayTasks: (context) => TodayTasksScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == AppRoutes.category) {
          final category = settings.arguments as String;

          return MaterialPageRoute(
            builder: (context) => const CategoryScreen(),
          );
        }
        return null;
      },
    );
  }
}
