import 'package:flutter/material.dart';

class AddMeetingScreen extends StatelessWidget {
  const AddMeetingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Meeting')),
      body: const Center(
        child: Text('Add Meeting Screen'),
      ),
    );
  }
}