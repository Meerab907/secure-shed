import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../utils/routes.dart';

class IdentityStep4Screen extends StatefulWidget {
  const IdentityStep4Screen({super.key});

  @override
  State<IdentityStep4Screen> createState() =>
      _IdentityStep4ScreenState();
}

class _IdentityStep4ScreenState
    extends State<IdentityStep4Screen> {

  final status = TextEditingController();
  final income = TextEditingController();

  DateTime? startDate;
  DateTime? endDate;

  final firestore = FirebaseFirestore.instance;
  final uid = FirebaseAuth.instance.currentUser!.uid;

  Future<void> pickStart() async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (date != null) {
      setState(() => startDate = date);
    }
  }

  Future<void> pickEnd() async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (date != null) {
      setState(() => endDate = date);
    }
  }

  void next() async {
    if (status.text.isEmpty || income.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Fill required fields"),
        ),
      );
      return;
    }

    await firestore
        .collection("identity_verifications")
        .doc(uid)
        .set({
      "employmentStatus": status.text.trim(),
      "employmentStartDate":
          startDate?.toIso8601String() ?? "",
      "employmentEndDate":
          endDate?.toIso8601String() ?? "",
      "monthlyIncome": income.text.trim(),

      "stepCompleted": 4,
      "updatedAt": DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));

    if (!mounted) return;

    Navigator.pushNamed(context, AppRoutes.identity5);
  }

  Widget buildField(
    TextEditingController controller,
    String label,
    IconData icon, {
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),

      child: TextField(
        controller: controller,
        keyboardType: keyboardType,

        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
        ),
      ),
    );
  }

  Widget dateTile({
    required String title,
    required DateTime? date,
    required VoidCallback onTap,
    required IconData icon,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),

      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(14),
      ),

      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF4B2E83)),

        title: Text(
          date == null
              ? title
              : "${date.day}/${date.month}/${date.year}",
        ),

        trailing: const Icon(Icons.arrow_forward_ios, size: 16),

        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryColor = Color(0xFF4B2E83);
    const Color backgroundColor = Color(0xFFF8EAF6);

    return Scaffold(
      backgroundColor: backgroundColor,

      appBar: AppBar(
        title: const Text(
          "Identity Verification",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              const SizedBox(height: 10),

              LinearProgressIndicator(
                value: 0.8,
                borderRadius: BorderRadius.circular(20),
              ),

              const SizedBox(height: 25),

              const Text(
                "Step 4 of 5",
                style: TextStyle(
                  fontSize: 16,
                  color: primaryColor,
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                "Employment Details",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
              ),

              const SizedBox(height: 10),

              Text(
                "Provide your employment and income information.",
                style: TextStyle(
                  color: Colors.grey.shade700,
                  fontSize: 15,
                ),
              ),

              const SizedBox(height: 30),

              Container(
                padding: const EdgeInsets.all(22),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),

                  boxShadow: [
                    BoxShadow(
                      color:
                          primaryColor.withValues(alpha: 0.08),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),

                child: Column(
                  children: [

                    buildField(
                      status,
                      "Employment Status *",
                      Icons.work,
                    ),

                    buildField(
                      income,
                      "Monthly Income *",
                      Icons.attach_money,
                      keyboardType: TextInputType.number,
                    ),

                    dateTile(
                      title: "Select Start Date",
                      date: startDate,
                      icon: Icons.calendar_month,
                      onTap: pickStart,
                    ),

                    dateTile(
                      title: "Select End Date",
                      date: endDate,
                      icon: Icons.event,
                      onTap: pickEnd,
                    ),

                    const SizedBox(height: 10),

                    SizedBox(
                      width: double.infinity,

                      child: ElevatedButton(
                        onPressed: next,

                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                            vertical: 16,
                          ),

                          shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(18),
                          ),
                        ),

                        child: const Text(
                          "Continue",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}