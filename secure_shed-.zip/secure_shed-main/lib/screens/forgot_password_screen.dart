import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/routes.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() =>
      _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState
    extends State<ForgotPasswordScreen> {

  final contactController =
      TextEditingController();

  final newPasswordController =
      TextEditingController();

  final confirmPasswordController =
      TextEditingController();

  final FirebaseFirestore firestore =
      FirebaseFirestore.instance;

  bool showNewPassword = false;
  bool showConfirmPassword = false;

  int currentSection = 1;

  String? userDocId;

  // Step 1: Check contact number
  Future<void> reset() async {
    String contact =
        contactController.text.trim();

    if (contact.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
              "Enter contact number"),
        ),
      );
      return;
    }

    try {
      QuerySnapshot result =
          await firestore
              .collection('users')
              .where(
                'contactNumber',
                isEqualTo: contact,
              )
              .get();

      if (result.docs.isNotEmpty) {
        userDocId =
            result.docs.first.id;

        setState(() {
          currentSection = 2;
        });
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          const SnackBar(
            content: Text(
              "Contact number not found",
            ),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text("$e"),
        ),
      );
    }
  }

  // Step 2: Update password
  Future<void> updatePassword() async {
    String password =
        newPasswordController.text
            .trim();

    String confirm =
        confirmPasswordController
            .text
            .trim();

    if (password.isEmpty ||
        confirm.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
              "Fill all fields"),
        ),
      );
      return;
    }

    if (password != confirm) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
              "Passwords do not match"),
        ),
      );
      return;
    }

    try {
      await firestore
          .collection('users')
          .doc(userDocId)
          .update({
        'password': password,
      });

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            "Password Updated",
          ),
        ),
      );

      Navigator.pushReplacementNamed(
        context,
        AppRoutes.login,
      );
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text("$e"),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "FORGOT YOUR PASSWORD?",
        ),
      ),

      body: Padding(
        padding:
            const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: currentSection == 1
              ? Column(
                  children: [

                    const SizedBox(
                        height: 30),

                    // Icon
                    const Icon(
                      Icons.lock_open,
                      size: 120,
                    ),

                    const SizedBox(
                        height: 20),

                    const Text(
                      "Please enter your registered contact number\nWe will reset your password",
                      textAlign:
                          TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                      ),
                    ),

                    const SizedBox(
                        height: 30),

                    // Contact Number
                    TextField(
                      controller:
                          contactController,
                      keyboardType:
                          TextInputType
                              .phone,
                      decoration:
                          const InputDecoration(
                        prefixIcon:
                            Icon(
                                Icons.phone),
                        labelText:
                            "Contact Number",
                        border:
                            OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(
                        height: 30),

                    SizedBox(
                      width:
                          double.infinity,
                      child:
                          ElevatedButton(
                        onPressed:
                            reset,
                        child:
                            const Text(
                          "Reset",
                        ),
                      ),
                    ),
                  ],
                )

              // Section 2
              : Column(
                  children: [

                    const SizedBox(
                        height: 30),

                    const Icon(
                      Icons.laptop_mac,
                      size: 120,
                    ),

                    const SizedBox(
                        height: 20),

                    const Text(
                      "Please enter your new password",
                      style: TextStyle(
                          fontSize: 16),
                    ),

                    const SizedBox(
                        height: 30),

                    // New Password
                    TextField(
                      controller:
                          newPasswordController,
                      obscureText:
                          !showNewPassword,
                      decoration:
                          InputDecoration(
                        prefixIcon:
                            const Icon(
                                Icons.lock),
                        labelText:
                            "New Password",

                        border:
                            const OutlineInputBorder(),

                        suffixIcon:
                            IconButton(
                          icon: Icon(
                            showNewPassword
                                ? Icons
                                    .visibility
                                : Icons
                                    .visibility_off,
                          ),
                          onPressed:
                              () {
                            setState(() {
                              showNewPassword =
                                  !showNewPassword;
                            });
                          },
                        ),
                      ),
                    ),

                    const SizedBox(
                        height: 20),

                    // Confirm Password
                    TextField(
                      controller:
                          confirmPasswordController,
                      obscureText:
                          !showConfirmPassword,
                      decoration:
                          InputDecoration(
                        prefixIcon:
                            const Icon(
                                Icons.lock),
                        labelText:
                            "Confirm New Password",

                        border:
                            const OutlineInputBorder(),

                        suffixIcon:
                            IconButton(
                          icon: Icon(
                            showConfirmPassword
                                ? Icons
                                    .visibility
                                : Icons
                                    .visibility_off,
                          ),
                          onPressed:
                              () {
                            setState(() {
                              showConfirmPassword =
                                  !showConfirmPassword;
                            });
                          },
                        ),
                      ),
                    ),

                    const SizedBox(
                        height: 30),

                    SizedBox(
                      width:
                          double.infinity,
                      child:
                          ElevatedButton(
                        onPressed:
                            updatePassword,
                        child:
                            const Text(
                          "Submit",
                        ),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}