import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../utils/routes.dart';

class IdentityStep3Screen extends StatefulWidget {
  const IdentityStep3Screen({super.key});

  @override
  State<IdentityStep3Screen> createState() =>
      _IdentityStep3ScreenState();
}

class _IdentityStep3ScreenState
    extends State<IdentityStep3Screen> {

  final phone = TextEditingController();
  final email = TextEditingController();

  String preferredContact = "Phone";

  final firestore = FirebaseFirestore.instance;
  final uid = FirebaseAuth.instance.currentUser!.uid;

  void next() async {
    if (phone.text.isEmpty || email.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Fill required fields"),
        ),
      );
      return;
    }

    await firestore
        .collection("identity_verifications")
        .doc(uid)
        .set({
      "phoneNumber": phone.text.trim(),
      "email": email.text.trim(),
      "preferredContact": preferredContact,

      "stepCompleted": 3,
      "updatedAt": DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));

    if (!mounted) return;

    Navigator.pushNamed(context, AppRoutes.identity4);
  }

  Widget buildField(
    TextEditingController controller,
    String label,
    IconData icon, {
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),

      child: TextField(
        controller: controller,
        keyboardType: keyboardType,

        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryColor = Color(0xFF4B2E83);
    const Color backgroundColor = Color(0xFFF8EAF6);

    return Scaffold(
      backgroundColor: backgroundColor,

      appBar: AppBar(
        title: const Text(
          "Identity Verification",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              const SizedBox(height: 10),

              LinearProgressIndicator(
                value: 0.6,
                borderRadius: BorderRadius.circular(20),
              ),

              const SizedBox(height: 25),

              const Text(
                "Step 3 of 5",
                style: TextStyle(
                  fontSize: 16,
                  color: primaryColor,
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                "Contact Information",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
              ),

              const SizedBox(height: 10),

              Text(
                "Provide your contact details for verification and communication.",
                style: TextStyle(
                  color: Colors.grey.shade700,
                  fontSize: 15,
                ),
              ),

              const SizedBox(height: 30),

              Container(
                padding: const EdgeInsets.all(22),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),

                  boxShadow: [
                    BoxShadow(
                      color: primaryColor.withValues(alpha: 0.08),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),

                child: Column(
                  children: [

                    buildField(
                      phone,
                      "Phone Number *",
                      Icons.phone,
                      keyboardType: TextInputType.phone,
                    ),

                    buildField(
                      email,
                      "Email Address *",
                      Icons.email,
                      keyboardType: TextInputType.emailAddress,
                    ),

                    const SizedBox(height: 10),

                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),

                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.grey.shade300,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),

                      child: DropdownButtonFormField<String>(
                        value: preferredContact,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                        ),

                        items: const [
                          DropdownMenuItem(
                            value: "Phone",
                            child: Text("Preferred: Phone"),
                          ),
                          DropdownMenuItem(
                            value: "Email",
                            child: Text("Preferred: Email"),
                          ),
                        ],

                        onChanged: (value) {
                          setState(() {
                            preferredContact = value!;
                          });
                        },
                      ),
                    ),

                    const SizedBox(height: 25),

                    SizedBox(
                      width: double.infinity,

                      child: ElevatedButton(
                        onPressed: next,

                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                            vertical: 16,
                          ),

                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),

                        child: const Text(
                          "Continue",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}