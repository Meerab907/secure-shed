import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../utils/routes.dart';

class IdentityStep2Screen extends StatefulWidget {
  const IdentityStep2Screen({super.key});

  @override
  State<IdentityStep2Screen> createState() =>
      _IdentityStep2ScreenState();
}

class _IdentityStep2ScreenState
    extends State<IdentityStep2Screen> {

  final country = TextEditingController();
  final province = TextEditingController();
  final city = TextEditingController();
  final zip = TextEditingController();
  final residency = TextEditingController();

  final firestore = FirebaseFirestore.instance;
  final uid = FirebaseAuth.instance.currentUser!.uid;

  void next() async {
    if (country.text.isEmpty ||
        province.text.isEmpty ||
        city.text.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Fill required fields"),
        ),
      );

      return;
    }

    await firestore
        .collection("identity_verifications")
        .doc(uid)
        .set({
      "country": country.text.trim(),
      "province": province.text.trim(),
      "city": city.text.trim(),
      "zipCode": zip.text.trim(),
      "residencyStatus": residency.text.trim(),

      "stepCompleted": 2,
      "updatedAt": DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));

    if (!mounted) return;

    Navigator.pushNamed(context, AppRoutes.identity3);
  }

  Widget buildField(
    TextEditingController controller,
    String label,
    IconData icon,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),

      child: TextField(
        controller: controller,

        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryColor = Color(0xFF4B2E83);
    const Color backgroundColor = Color(0xFFF8EAF6);

    return Scaffold(
      backgroundColor: backgroundColor,

      appBar: AppBar(
        title: const Text(
          "Identity Verification",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),

          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [

              const SizedBox(height: 10),

              LinearProgressIndicator(
                value: 0.4,
                borderRadius:
                    BorderRadius.circular(20),
              ),

              const SizedBox(height: 25),

              const Text(
                "Step 2 of 5",
                style: TextStyle(
                  fontSize: 16,
                  color: primaryColor,
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                "Address Information",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
              ),

              const SizedBox(height: 10),

              Text(
                "Provide your residential information for verification purposes.",
                style: TextStyle(
                  color: Colors.grey.shade700,
                  fontSize: 15,
                ),
              ),

              const SizedBox(height: 30),

              Container(
                padding: const EdgeInsets.all(22),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.circular(24),

                  boxShadow: [
                    BoxShadow(
                      color: primaryColor.withValues(
                        alpha: 0.08,
                      ),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),

                child: Column(
                  children: [

                    buildField(
                      country,
                      "Country *",
                      Icons.public,
                    ),

                    buildField(
                      province,
                      "Province *",
                      Icons.map,
                    ),

                    buildField(
                      city,
                      "City *",
                      Icons.location_city,
                    ),

                    buildField(
                      zip,
                      "Zip Code",
                      Icons.pin_drop,
                    ),

                    buildField(
                      residency,
                      "Residency Status",
                      Icons.home_work,
                    ),

                    const SizedBox(height: 10),

                    SizedBox(
                      width: double.infinity,

                      child: ElevatedButton(
                        onPressed: next,

                        style: ElevatedButton.styleFrom(
                          padding:
                              const EdgeInsets.symmetric(
                            vertical: 16,
                          ),

                          shape:
                              RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(
                              18,
                            ),
                          ),
                        ),

                        child: const Text(
                          "Continue",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}