import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/local_security_storage.dart';
import '../utils/routes.dart';

class FaceScreen extends StatefulWidget {
  const FaceScreen({super.key});

  @override
  State<FaceScreen> createState() =>
      _FaceScreenState();
}

class _FaceScreenState extends State<FaceScreen> {
  String? facePath;

  Future<void> captureFace() async {
    final picker = ImagePicker();

    final image = await picker.pickImage(
      source: ImageSource.camera,
    );

    if (image != null) {
      final file = File(image.path);

      final savedPath =
          await LocalSecurityStorage.saveImage(
        file,
        "face",
      );

      setState(() {
        facePath = savedPath;
      });

      await LocalSecurityStorage
          .setBiometricEnabled(true);
    }
  }

  void next() {
    if (facePath == null) return;

    Navigator.pushNamed(
      context,
      AppRoutes.fingerprint,
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryColor = Color(0xFF4B2E83);
    const Color backgroundColor = Color(0xFFF8EAF6);

    return Scaffold(
      backgroundColor: backgroundColor,

      appBar: AppBar(
        title: const Text(
          "Face Verification",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24),

            child: Column(
              children: [

                const SizedBox(height: 30),

                Container(
                  padding: const EdgeInsets.all(30),

                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,

                    boxShadow: [
                      BoxShadow(
                        color:
                            primaryColor.withOpacity(0.15),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),

                  child: const Icon(
                    Icons.face_retouching_natural,
                    size: 100,
                    color: primaryColor,
                  ),
                ),

                const SizedBox(height: 35),

                const Text(
                  "Face Authentication",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: primaryColor,
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  "Capture a clear selfie for secure identity verification.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey.shade700,
                  ),
                ),

                const SizedBox(height: 35),

                if (facePath != null)
                  Container(
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(20),

                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(
                              0.1),
                          blurRadius: 10,
                        ),
                      ],
                    ),

                    child: ClipRRect(
                      borderRadius:
                          BorderRadius.circular(20),

                      child: Image.file(
                        File(facePath!),
                        height: 220,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),

                const SizedBox(height: 35),

                SizedBox(
                  width: double.infinity,

                  child: ElevatedButton.icon(
                    onPressed: captureFace,

                    icon: const Icon(Icons.camera_alt),

                    label: Text(
                      facePath == null
                          ? "Take Selfie"
                          : "Retake Selfie",
                    ),

                    style: ElevatedButton.styleFrom(
                      padding:
                          const EdgeInsets.symmetric(
                        vertical: 18,
                      ),

                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(18),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,

                  child: ElevatedButton(
                    onPressed:
                        facePath != null ? next : null,

                    style: ElevatedButton.styleFrom(
                      padding:
                          const EdgeInsets.symmetric(
                        vertical: 18,
                      ),

                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(18),
                      ),
                    ),

                    child: const Text("Continue"),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}