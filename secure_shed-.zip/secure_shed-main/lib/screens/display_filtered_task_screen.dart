import 'package:flutter/material.dart';

import '../models/task_model.dart';
import '../services/task_service.dart';

class DisplayFilteredTaskScreen extends StatefulWidget {
  const DisplayFilteredTaskScreen({super.key});

  @override
  State<DisplayFilteredTaskScreen> createState() =>
      _DisplayFilteredTaskScreenState();
}

class _DisplayFilteredTaskScreenState
    extends State<DisplayFilteredTaskScreen> {

  final taskService = TaskService();

  String selectedCategory = "All";

  final List<String> categories = [
    "All",
    "Work",
    "Personal",
    "Wishlist",
    "Birthday"
  ];

  // 🔥 PRIORITY COLORS
  Color getPriorityColor(String? priority) {
    switch (priority) {
      case "High":
        return Colors.red;
      case "Medium":
        return Colors.orange;
      case "Low":
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  // 🔥 STATUS ORDER (Pending → In Progress → Completed)
  int getStatusOrder(String? status) {
    switch (status) {
      case "Pending":
        return 0;
      case "In Progress":
        return 1;
      case "Completed":
        return 2;
      default:
        return 3;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tasks Dashboard"),
      ),

      body: Column(
        children: [

          // 🔵 CATEGORY FILTER
          SizedBox(
            height: 60,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              itemBuilder: (context, index) {

                final cat = categories[index];

                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: ChoiceChip(
                    label: Text(cat),
                    selected: selectedCategory == cat,
                    onSelected: (_) {
                      setState(() {
                        selectedCategory = cat;
                      });
                    },
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 10),

          // 🔵 TASK LIST
          Expanded(
            child: StreamBuilder<List<TaskModel>>(
              stream: taskService.getTasks(
                category: selectedCategory,
              ),

              builder: (context, snapshot) {

                if (!snapshot.hasData) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }

                final tasks = snapshot.data!;

                // 🔥 SORT BY STATUS
                tasks.sort((a, b) =>
                    getStatusOrder(a.status)
                        .compareTo(getStatusOrder(b.status)));

                if (tasks.isEmpty) {
                  return const Center(
                    child: Text("No Tasks Found"),
                  );
                }

                return ListView.builder(
                  itemCount: tasks.length,
                  itemBuilder: (context, index) {

                    final task = tasks[index];

                    return Card(
  margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
  elevation: 3,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(16),
  ),
  child: Padding(
    padding: const EdgeInsets.all(14),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        // TITLE + PRIORITY
        Row(
          children: [
            Expanded(
              child: Text(
                task.title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: getPriorityColor(task.priority).withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                task.priority,
                style: TextStyle(
                  color: getPriorityColor(task.priority),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 10),

        // CATEGORY + LOCATION
        Row(
          children: [
            const Icon(Icons.category, size: 16),
            const SizedBox(width: 5),
            Text(task.category),
            const SizedBox(width: 15),
            const Icon(Icons.location_on, size: 16),
            const SizedBox(width: 5),
            Expanded(child: Text(task.location)),
          ],
        ),

        const SizedBox(height: 10),

        // STATUS
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: task.status == "Completed"
                ? Colors.green.withValues(alpha: 0.15)
                : task.status == "In Progress"
                    ? Colors.blue.withValues(alpha: 0.15)
                    : Colors.orange.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            task.status,
            style: TextStyle(
              color: task.status == "Completed"
                  ? Colors.green
                  : task.status == "In Progress"
                      ? Colors.blue
                      : Colors.orange,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),

        const SizedBox(height: 10),

        // ACTIONS
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            PopupMenuButton(
              itemBuilder: (context) => const [
                PopupMenuItem(value: "edit", child: Text("Edit")),
                PopupMenuItem(value: "delete", child: Text("Delete")),
              ],
              onSelected: (value) {
                if (value == "delete") {
                  taskService.deleteTask(task.taskId);
                }

                if (value == "edit") {
                  Navigator.pushNamed(
                    context,
                    '/editTask',
                    arguments: task,
                  );
                }
              },
            ),
          ],
        ),
      ],
    ),
  ),
);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}