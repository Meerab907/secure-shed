import 'package:flutter/material.dart';
import '../services/task_service.dart';
import '../models/task_model.dart';

class RescheduleTaskScreen extends StatefulWidget {
  const RescheduleTaskScreen({super.key});

  @override
  State<RescheduleTaskScreen> createState() =>
      _RescheduleTaskScreenState();
}

class _RescheduleTaskScreenState extends State<RescheduleTaskScreen> {
  DateTime? selectedDate;

  final TaskService service = TaskService();

  Future<void> pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  Future<void> saveReschedule() async {
    if (selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select a date")),
      );
      return;
    }

    final task = ModalRoute.of(context)!.settings.arguments as TaskModel;

    await service.updateTask(task);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Task rescheduled successfully")),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Reschedule Task")),

      body: Padding(
        padding: const EdgeInsets.all(16),

        child: Column(
          children: [
            const Text(
              "Select New Date",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 20),

            ElevatedButton.icon(
              onPressed: pickDate,
              icon: const Icon(Icons.calendar_month),
              label: const Text("Pick Date"),
            ),

            const SizedBox(height: 20),

            if (selectedDate != null)
              Text("Selected: ${selectedDate!.toLocal()}"),

            const Spacer(),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("Cancel"),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: saveReschedule,
                    child: const Text("Save"),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}