import 'package:flutter/material.dart';
import '../models/task_model.dart';
import '../services/task_service.dart';

class TodayTasksScreen extends StatelessWidget {
  TodayTasksScreen({super.key});

  final taskService = TaskService();

  // 🎯 PRIORITY COLORS
  Color getPriorityColor(String priority) {
    switch (priority) {
      case "High":
        return Colors.red;
      case "Medium":
        return Colors.orange;
      case "Low":
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  // 🎯 STATUS COLORS
  Color getStatusColor(String status) {
    switch (status) {
      case "Completed":
        return Colors.green;
      case "In Progress":
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB),

      appBar: AppBar(
        title: const Text("Today's Tasks"),
        centerTitle: true,
        elevation: 0,
      ),

      body: StreamBuilder<List<TaskModel>>(
        stream: taskService.getTodayTasks(),

        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final tasks = snapshot.data!;

          if (tasks.isEmpty) {
            return const Center(
              child: Text(
                "No tasks for today",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            );
          }

          return Column(
            children: [

              // 📊 HEADER
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    const Text(
                      "Today's Tasks",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      "${tasks.length} tasks",
                      style: const TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),

              // 📋 LIST
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: tasks.length,

                  itemBuilder: (context, index) {
                    final task = tasks[index];

                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),

                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.06),
                            blurRadius: 12,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),

                      child: Padding(
                        padding: const EdgeInsets.all(14),

                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            // 🔥 TITLE + PRIORITY
                            Row(
                              children: [

                                Expanded(
                                  child: Text(
                                    task.title,
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),

                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 5,
                                  ),

                                  decoration: BoxDecoration(
                                    color: getPriorityColor(task.priority)
                                        .withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(20),
                                  ),

                                  child: Text(
                                    task.priority,
                                    style: TextStyle(
                                      color: getPriorityColor(task.priority),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 10),

                            // 📌 CATEGORY + LOCATION
                            Row(
                              children: [
                                const Icon(Icons.category,
                                    size: 16, color: Colors.grey),
                                const SizedBox(width: 5),
                                Text(
                                  task.category,
                                  style: const TextStyle(color: Colors.grey),
                                ),
                                const SizedBox(width: 12),
                                const Icon(Icons.location_on,
                                    size: 16, color: Colors.grey),
                                const SizedBox(width: 5),
                                Expanded(
                                  child: Text(
                                    task.location,
                                    style: const TextStyle(color: Colors.grey),
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 12),

                            // 🔵 STATUS BADGE
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),

                              decoration: BoxDecoration(
                                color: getStatusColor(task.status)
                                    .withOpacity(0.15),
                                borderRadius: BorderRadius.circular(20),
                              ),

                              child: Text(
                                task.status,
                                style: TextStyle(
                                  color: getStatusColor(task.status),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}