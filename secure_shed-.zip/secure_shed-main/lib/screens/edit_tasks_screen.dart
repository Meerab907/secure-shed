import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../services/task_service.dart';
import '../models/task_model.dart';

class EditTaskScreen extends StatefulWidget {
  final TaskModel task;

  const EditTaskScreen({super.key, required this.task});

  @override
  State<EditTaskScreen> createState() => _EditTaskScreenState();
}

class _EditTaskScreenState extends State<EditTaskScreen> {
  final taskService = TaskService();

  late TextEditingController titleController;
  late TextEditingController descController;
  late TextEditingController categoryController;
  late TextEditingController locationController;
  late TextEditingController notesController;

  late DateTime selectedDate;
  late TimeOfDay startTime;
  late TimeOfDay endTime;

  @override
  void initState() {
    super.initState();

    titleController = TextEditingController(text: widget.task.title);
    descController = TextEditingController(text: widget.task.description);
    categoryController = TextEditingController(text: widget.task.category);
    locationController = TextEditingController(text: widget.task.location);
    notesController = TextEditingController(text: widget.task.notes);

    selectedDate = widget.task.date;

    startTime = TimeOfDay(
      hour: widget.task.startTime.hour,
      minute: widget.task.startTime.minute,
    );

    endTime = TimeOfDay(
      hour: widget.task.endTime.hour,
      minute: widget.task.endTime.minute,
    );
  }

  InputDecoration inputStyle(String label) {
    return InputDecoration(
      labelText: label,

      filled: true,
      fillColor: const Color(0xFFF1ECFA),

      contentPadding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 18,
      ),

      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),

      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),

      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(
          color: Color(0xFF4B2E83),
          width: 1.5,
        ),
      ),

      labelStyle: TextStyle(
        color: Colors.grey.shade700,
      ),
    );
  }

  Future<void> updateTask() async {
    final startDateTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      startTime.hour,
      startTime.minute,
    );

    final endDateTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      endTime.hour,
      endTime.minute,
    );

    final updatedTask = TaskModel(
      taskId: widget.task.taskId,
      userId: FirebaseAuth.instance.currentUser!.uid,
      title: titleController.text.trim(),
      description: descController.text.trim(),
      category: categoryController.text.trim(),
      location: locationController.text.trim(),
      date: selectedDate,
      startTime: startDateTime,
      endTime: endDateTime,
      notes: notesController.text.trim(),
      priority: widget.task.priority,
      status: widget.task.status,
      createdAt: widget.task.createdAt,
      updatedAt: DateTime.now(),
    );

    await taskService.updateTask(updatedTask);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Task Updated Successfully"),
      ),
    );

    Navigator.pop(context);
  }

  Widget sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, top: 6),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.bold,
          color: Color(0xFF4B2E83),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF4B2E83);

    return Scaffold(
      backgroundColor: const Color(0xFFF8F5FD),

      appBar: AppBar(
        title: const Text(
          "Edit Task",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),

        centerTitle: true,
        elevation: 0,
        backgroundColor: primary,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              // HEADER CARD
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),

                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFF4B2E83),
                      Color(0xFF7A5CD6),
                    ],
                  ),

                  borderRadius: BorderRadius.circular(24),

                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.08),
                      blurRadius: 14,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),

                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    Text(
                      "Edit Your Task",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),

                    SizedBox(height: 8),

                    Text(
                      "Update task details and keep your schedule organized.",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              sectionTitle("Task Title"),

              TextField(
                controller: titleController,
                decoration: inputStyle("Enter task title"),
              ),

              const SizedBox(height: 18),

              sectionTitle("Description"),

              TextField(
                controller: descController,
                maxLines: 3,
                decoration: inputStyle("Enter task description"),
              ),

              const SizedBox(height: 18),

              sectionTitle("Category"),

              TextField(
                controller: categoryController,
                decoration: inputStyle("Enter category"),
              ),

              const SizedBox(height: 18),

              sectionTitle("Location"),

              TextField(
                controller: locationController,
                decoration: inputStyle("Enter location"),
              ),

              const SizedBox(height: 18),

              sectionTitle("Notes"),

              TextField(
                controller: notesController,
                maxLines: 3,
                decoration: inputStyle("Additional notes"),
              ),

              const SizedBox(height: 35),

              SizedBox(
                width: double.infinity,
                height: 56,

                child: ElevatedButton(
                  onPressed: updateTask,

                  style: ElevatedButton.styleFrom(
                    backgroundColor: primary,

                    elevation: 3,

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),

                  child: const Text(
                    "Save Changes",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}