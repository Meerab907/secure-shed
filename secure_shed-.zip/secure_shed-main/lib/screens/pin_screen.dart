import 'package:flutter/material.dart';
import '../services/local_security_storage.dart';
import '../utils/routes.dart';

class PinScreen extends StatefulWidget {
  const PinScreen({super.key});

  @override
  State<PinScreen> createState() => _PinScreenState();
}

class _PinScreenState extends State<PinScreen> {
  String pin = "";

  void addDigit(String d) {
    if (pin.length < 6) {
      setState(() => pin += d);
    }
  }

  void removeDigit() {
    if (pin.isNotEmpty) {
      setState(() => pin = pin.substring(0, pin.length - 1));
    }
  }

  Future<void> savePin() async {
    if (pin.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Enter a 6-digit PIN")),
      );
      return;
    }

    await LocalSecurityStorage.savePin(pin);

    if (!mounted) return;

    Navigator.pushNamedAndRemoveUntil(
      context,
      AppRoutes.home,
      (route) => false,
    );
  }

  Widget pinDot(int index) {
    final filled = index < pin.length;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      margin: const EdgeInsets.symmetric(horizontal: 6),
      width: filled ? 14 : 12,
      height: filled ? 14 : 12,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: filled ? const Color(0xFF4B2E83) : Colors.grey.shade300,
      ),
    );
  }

  Widget keyButton(String value, {IconData? icon}) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () {
        if (value == "del") {
          removeDigit();
        } else {
          addDigit(value);
        }
      },
      child: Container(
        margin: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: icon != null
              ? Icon(icon, color: const Color(0xFF4B2E83))
              : Text(
                  value,
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF4B2E83),
                  ),
                ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF4B2E83);
    const bg = Color(0xFFF8EAF6);

    final h = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: bg,

      appBar: AppBar(
        title: const Text(
          "Create PIN",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22),
          child: Column(
            children: [

              SizedBox(height: h * 0.03),

              const Icon(Icons.lock_outline, size: 70, color: primary),

              const SizedBox(height: 14),

              const Text(
                "Secure Your Account",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: primary,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                "Create a 6-digit PIN for quick and secure access.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade700),
              ),

              SizedBox(height: h * 0.04),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(6, pinDot),
              ),

              SizedBox(height: h * 0.04),

              Expanded(
                child: GridView(
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1,
                  ),
                  children: [
                    for (var i = 1; i <= 9; i++) keyButton(i.toString()),
                    const SizedBox(), // empty slot
                    keyButton("0"),
                    keyButton("del", icon: Icons.backspace_outlined),
                  ],
                ),
              ),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: pin.length == 6 ? savePin : null,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  child: const Text(
                    "Finish Setup",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}