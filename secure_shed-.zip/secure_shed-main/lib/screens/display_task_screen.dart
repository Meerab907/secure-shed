import 'package:flutter/material.dart';
import 'edit_tasks_screen.dart';
import '../models/task_model.dart';
import '../services/task_service.dart';
import '../utils/status_helper.dart';

class DisplayTaskScreen extends StatefulWidget {
  const DisplayTaskScreen({super.key});

  @override
  State<DisplayTaskScreen> createState() => _DisplayTaskScreenState();
}

class _DisplayTaskScreenState extends State<DisplayTaskScreen> {
  final taskService = TaskService();

  String selectedCategory = "All";

  final List<String> categories = [
    "All",
    "Work",
    "Personal",
    "Wishlist",
    "Birthday"
  ];

  // 🔥 PRIORITY COLORS
  Color getPriorityColor(String? priority) {
    switch (priority) {
      case "High":
        return Colors.red;
      case "Medium":
        return Colors.orange;
      case "Low":
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  Color getStatusColor(String status) {
    switch (status) {
      case "Completed":
        return Colors.green;
      case "In Progress":
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF4B2E83);

    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB),

      appBar: AppBar(
        title: const Text("All Tasks"),
        backgroundColor: primary,
        centerTitle: true,
      ),

      body: Column(
        children: [

          // 🔥 CATEGORY FILTER (modern pills)
          Container(
            height: 55,
            margin: const EdgeInsets.only(top: 10),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              itemCount: categories.length,
              itemBuilder: (context, index) {
                final cat = categories[index];

                final isSelected = selectedCategory == cat;

                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: ChoiceChip(
                    label: Text(cat),
                    selected: isSelected,
                    selectedColor: primary,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : Colors.black,
                    ),
                    onSelected: (_) {
                      setState(() {
                        selectedCategory = cat;
                      });
                    },
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 10),

          // 📋 TASK LIST
          Expanded(
            child: StreamBuilder<List<TaskModel>>(
              stream: taskService.getTasks(),

              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                List<TaskModel> tasks = snapshot.data!;

                // filter
                if (selectedCategory != "All") {
                  tasks = tasks
                      .where((t) => t.category == selectedCategory)
                      .toList();
                }

                if (tasks.isEmpty) {
                  return const Center(
                    child: Text("No Tasks Found"),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(10),
                  itemCount: tasks.length,

                  itemBuilder: (context, index) {
                    final task = tasks[index];

                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),

                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          )
                        ],
                      ),

                      child: Padding(
                        padding: const EdgeInsets.all(14),

                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            // 🔥 TITLE + PRIORITY
                            Row(
                              children: [

                                Expanded(
                                  child: Text(
                                    task.title,
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),

                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 5,
                                  ),
                                  decoration: BoxDecoration(
                                    color: getPriorityColor(task.priority)
                                        .withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(
                                    task.priority,
                                    style: TextStyle(
                                      color: getPriorityColor(task.priority),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 10),

                            // 📌 CATEGORY + STATUS
                            Row(
                              children: [
                                Icon(Icons.category,
                                    size: 16, color: Colors.grey.shade600),
                                const SizedBox(width: 5),
                                Text(task.category),

                                const SizedBox(width: 15),

                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: getStatusColor(task.status)
                                        .withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(
                                    task.status,
                                    style: TextStyle(
                                      color: getStatusColor(task.status),
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 12),

                            // 📍 LOCATION
                            Row(
                              children: [
                                Icon(Icons.location_on,
                                    size: 16, color: Colors.grey.shade600),
                                const SizedBox(width: 5),
                                Expanded(
                                  child: Text(
                                    task.location,
                                    style: TextStyle(
                                      color: Colors.grey.shade700,
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 12),

                            // 🔥 ACTIONS
                            Align(
                              alignment: Alignment.centerRight,
                              child:PopupMenuButton<String>(
  onSelected: (value) async {
    if (value == "edit") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => EditTaskScreen(task: task),
        ),
      );
    }

    if (value == "delete") {
      await taskService.deleteTask(task.taskId);
    }

    if (value == "pending" ||
        value == "in_progress" ||
        value == "completed") {
      await taskService.updateTaskStatus(task.taskId, value);
    }
  },

  itemBuilder: (context) => const [
    PopupMenuItem(
      value: "edit",
      child: Text("Edit Task"),
    ),
    PopupMenuItem(
      value: "delete",
      child: Text("Delete Task"),
    ),

    PopupMenuDivider(),

    PopupMenuItem(
      value: "pending",
      child: Text("Mark Pending"),
    ),
    PopupMenuItem(
      value: "in_progress",
      child: Text("Mark In Progress"),
    ),
    PopupMenuItem(
      value: "completed",
      child: Text("Mark Completed"),
    ),
  ],
),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}