import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../utils/routes.dart';

class IdentityStep1Screen extends StatefulWidget {
  const IdentityStep1Screen({super.key});

  @override
  State<IdentityStep1Screen> createState() =>
      _IdentityStep1ScreenState();
}

class _IdentityStep1ScreenState
    extends State<IdentityStep1Screen> {

  final firstName = TextEditingController();
  final middleName = TextEditingController();
  final lastName = TextEditingController();
  final dob = TextEditingController();
  final ssn = TextEditingController();

  final firestore = FirebaseFirestore.instance;
  final uid = FirebaseAuth.instance.currentUser!.uid;

  void next() async {
    if (firstName.text.isEmpty ||
        lastName.text.isEmpty ||
        dob.text.isEmpty ||
        ssn.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Fill required fields"),
        ),
      );
      return;
    }

    await firestore
        .collection("identity_verifications")
        .doc(uid)
        .set({
      "firstName": firstName.text.trim(),
      "middleName": middleName.text.trim(),
      "lastName": lastName.text.trim(),
      "dateOfBirth": dob.text.trim(),
      "ssnLast4": ssn.text.trim(),
      "stepCompleted": 1,
      "updatedAt": DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));

    if (!mounted) return;

    Navigator.pushNamed(context, AppRoutes.identity2);
  }

  Widget buildField(
    TextEditingController controller,
    String label,
    IconData icon,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color backgroundColor = Color(0xFFF8EAF6);
    const Color primaryColor = Color(0xFF4B2E83);

    return Scaffold(
      backgroundColor: backgroundColor,

      appBar: AppBar(
        title: const Text(
          "Identity Verification",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              const SizedBox(height: 10),

              LinearProgressIndicator(
                value: 0.2,
                borderRadius: BorderRadius.circular(20),
              ),

              const SizedBox(height: 25),

              const Text(
                "Step 1 of 5",
                style: TextStyle(
                  fontSize: 16,
                  color: primaryColor,
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                "Personal Information",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
              ),

              const SizedBox(height: 10),

              Text(
                "Please provide your personal details for identity verification.",
                style: TextStyle(
                  color: Colors.grey.shade700,
                  fontSize: 15,
                ),
              ),

              const SizedBox(height: 30),

              Container(
                padding: const EdgeInsets.all(22),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),

                  boxShadow: [
                    BoxShadow(
                      color: primaryColor.withValues(alpha: 0.08),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),

                child: Column(
                  children: [

                    buildField(
                      firstName,
                      "First Name *",
                      Icons.person_outline,
                    ),

                    buildField(
                      middleName,
                      "Middle Name",
                      Icons.person_outline,
                    ),

                    buildField(
                      lastName,
                      "Last Name *",
                      Icons.person,
                    ),

                    buildField(
                      dob,
                      "Date of Birth *",
                      Icons.calendar_month,
                    ),

                    buildField(
                      ssn,
                      "Last 4 SSN *",
                      Icons.badge_outlined,
                    ),

                    const SizedBox(height: 10),

                    SizedBox(
                      width: double.infinity,

                      child: ElevatedButton(
                        onPressed: next,

                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                            vertical: 16,
                          ),

                          shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(18),
                          ),
                        ),

                        child: const Text(
                          "Continue",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}