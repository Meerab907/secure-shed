import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/image_service.dart';
import '../utils/routes.dart';

class IdentityStep5Screen extends StatefulWidget {
  const IdentityStep5Screen({super.key});

  @override
  State<IdentityStep5Screen> createState() =>
      _IdentityStep5ScreenState();
}

class _IdentityStep5ScreenState extends State<IdentityStep5Screen> {
  String? selfie;
  String? front;
  String? back;

  final imageService = ImageService();
  final firestore = FirebaseFirestore.instance;
  final uid = FirebaseAuth.instance.currentUser!.uid;

  final Color primaryColor = const Color(0xFF4B2E83);
  final Color backgroundColor = const Color(0xFFF8EAF6);

  Future<void> takeSelfie() async {
    final path = await imageService.captureAndSaveImage();
    if (path != null) setState(() => selfie = path);
  }

  Future<void> takeFront() async {
    final path = await imageService.captureAndSaveImage();
    if (path != null) setState(() => front = path);
  }

  Future<void> takeBack() async {
    final path = await imageService.captureAndSaveImage();
    if (path != null) setState(() => back = path);
  }

  void finish() async {
    if (selfie == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Selfie is required")),
      );
      return;
    }

    await firestore.collection("identity_verifications").doc(uid).set({
      "selfiePath": selfie ?? "",
      "cnicFrontPath": front ?? "",
      "cnicBackPath": back ?? "",
      "status": "pending",
      "stepCompleted": 5,
      "createdAt": DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));

    if (!mounted) return;

    Navigator.pushReplacementNamed(context, AppRoutes.securityIntro);
  }

  Widget _buildUploadCard({
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    File? image,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: primaryColor,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 12),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: onTap,
              icon: const Icon(Icons.camera_alt),
              label: const Text("Capture"),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ),

          if (image != null) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(
                image,
                height: 140,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ]
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,

      appBar: AppBar(
        title: const Text(
          "Identity Verification (Step 5)",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),

              Text(
                "Final Step: Document Verification",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
              ),

              const SizedBox(height: 6),

              Text(
                "Please provide selfie and CNIC images for verification.",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade700,
                ),
              ),

              const SizedBox(height: 25),

              _buildUploadCard(
                title: "Selfie Verification",
                subtitle: "Take a clear selfie of your face",
                onTap: takeSelfie,
                image: selfie != null ? File(selfie!) : null,
              ),

              _buildUploadCard(
                title: "CNIC Front Side",
                subtitle: "Capture front side of your ID card",
                onTap: takeFront,
                image: front != null ? File(front!) : null,
              ),

              _buildUploadCard(
                title: "CNIC Back Side",
                subtitle: "Capture back side of your ID card",
                onTap: takeBack,
                image: back != null ? File(back!) : null,
              ),

              const SizedBox(height: 10),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: finish,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text(
                    "Submit & Finish",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}