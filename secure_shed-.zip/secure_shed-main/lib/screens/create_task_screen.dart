import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uuid/uuid.dart';

import '../models/task_model.dart';
import '../services/task_service.dart';

class CreateTaskScreen extends StatefulWidget {
  const CreateTaskScreen({super.key});

  @override
  State<CreateTaskScreen> createState() => _CreateTaskScreenState();
}

class _CreateTaskScreenState extends State<CreateTaskScreen> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final locationController = TextEditingController();
  final notesController = TextEditingController();

  final TaskService taskService = TaskService();

  String category = "Work";
  String priority = "Medium";

  DateTime? selectedDate;
  TimeOfDay? startTime;
  TimeOfDay? endTime;

  bool isSaving = false;

  Future<void> pickDate() async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDate: DateTime.now(),
    );

    if (picked != null) {
      setState(() => selectedDate = picked);
    }
  }

  Future<void> pickTime(bool isStart) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          startTime = picked;
        } else {
          endTime = picked;
        }
      });
    }
  }

  Future<void> createTask() async {
    if (isSaving) return;

    setState(() => isSaving = true);

    try {
      // ✅ validation
      if (titleController.text.trim().isEmpty ||
          selectedDate == null ||
          startTime == null ||
          endTime == null) {
        setState(() => isSaving = false);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Fill all required fields")),
        );
        return;
      }

      // ✅ SAFE USER HANDLING
      User? user = FirebaseAuth.instance.currentUser;

      if (user == null) {
        user = await FirebaseAuth.instance.authStateChanges().first;
      }

      if (user == null) {
        setState(() => isSaving = false);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("User not logged in")),
        );
        return;
      }

      final startDateTime = DateTime(
        selectedDate!.year,
        selectedDate!.month,
        selectedDate!.day,
        startTime!.hour,
        startTime!.minute,
      );

      final endDateTime = DateTime(
        selectedDate!.year,
        selectedDate!.month,
        selectedDate!.day,
        endTime!.hour,
        endTime!.minute,
      );

      final newTask = TaskModel(
        taskId: const Uuid().v4(),
        userId: user.uid,
        title: titleController.text.trim(),
        description: descriptionController.text.trim(),
        category: category,
        location: locationController.text.trim(),
        date: selectedDate!,
        startTime: startDateTime,
        endTime: endDateTime,
        notes: notesController.text.trim(),
        priority: priority,
        status: "Pending",
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      // ✅ SAFE FETCH
      final existingTasks = await taskService.getTasksOnce();

      bool hasConflict = false;

      for (final task in existingTasks) {
        if (task.date.year != selectedDate!.year ||
            task.date.month != selectedDate!.month ||
            task.date.day != selectedDate!.day) {
          continue;
        }

        final overlap =
            newTask.startTime.isBefore(task.endTime) &&
            newTask.endTime.isAfter(task.startTime);

        if (overlap) {
          hasConflict = true;
          break;
        }
      }

      if (hasConflict) {
        final result = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text("Time Conflict"),
            content: const Text("This task overlaps with another task."),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text("Cancel"),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text("Keep Both"),
              ),
            ],
          ),
        );

        if (result != true) {
          setState(() => isSaving = false);
          return;
        }
      }

      await taskService.createTask(newTask);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Task Created Successfully")),
      );

      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      if (mounted) {
        setState(() => isSaving = false);
      }
    }
  }

  InputDecoration inputStyle(String label) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: Colors.grey.shade100,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    );
  }

  Widget sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 8),
      child: Text(
        text,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget chip(String text, bool selected, VoidCallback onTap) {
    return ActionChip(
      label: Text(selected ? "✓ $text" : text),
      backgroundColor: selected ? Colors.green.shade100 : Colors.grey.shade200,
      onPressed: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF4B2E83);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Create Task"),
        backgroundColor: primary,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            sectionTitle("Task Details"),

            TextField(
              controller: titleController,
              decoration: inputStyle("Title *"),
            ),
            const SizedBox(height: 10),

            TextField(
              controller: descriptionController,
              maxLines: 2,
              decoration: inputStyle("Description"),
            ),
            const SizedBox(height: 10),

            TextField(
              controller: locationController,
              decoration: inputStyle("Location"),
            ),
            const SizedBox(height: 10),

            TextField(
              controller: notesController,
              maxLines: 2,
              decoration: inputStyle("Notes"),
            ),

            sectionTitle("Category & Priority"),

            DropdownButtonFormField(
              value: category,
              decoration: inputStyle("Category"),
              items: const [
                DropdownMenuItem(value: "Work", child: Text("Work")),
                DropdownMenuItem(value: "Personal", child: Text("Personal")),
                DropdownMenuItem(value: "Wishlist", child: Text("Wishlist")),
                DropdownMenuItem(value: "Birthday", child: Text("Birthday")),
              ],
              onChanged: (v) => setState(() => category = v!),
            ),

            const SizedBox(height: 10),

            DropdownButtonFormField(
              value: priority,
              decoration: inputStyle("Priority"),
              items: const [
                DropdownMenuItem(value: "High", child: Text("High")),
                DropdownMenuItem(value: "Medium", child: Text("Medium")),
                DropdownMenuItem(value: "Low", child: Text("Low")),
              ],
              onChanged: (v) => setState(() => priority = v!),
            ),

            sectionTitle("Schedule"),

            Wrap(
              spacing: 10,
              children: [
                chip("Pick Date", selectedDate != null, pickDate),
                chip("Start Time", startTime != null, () => pickTime(true)),
                chip("End Time", endTime != null, () => pickTime(false)),
              ],
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: isSaving ? null : createTask,
                style: ElevatedButton.styleFrom(
                  backgroundColor: primary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: isSaving
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text("Save Task"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}