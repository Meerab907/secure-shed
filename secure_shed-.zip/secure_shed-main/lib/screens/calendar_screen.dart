import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import '../models/task_model.dart';
import '../services/task_service.dart';
import 'edit_tasks_screen.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime selectedDay = DateTime.now();
  final taskService = TaskService();

  Color getPriorityColor(String priority) {
    switch (priority) {
      case "High":
        return Colors.red;
      case "Medium":
        return Colors.orange;
      case "Low":
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  Color getStatusColor(String status) {
    switch (status) {
      case "Completed":
        return Colors.green;
      case "In Progress":
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }

  DateTime _parseDate(DateTime date) => date;

  List<TaskModel> _tasksForDay(List<TaskModel> tasks, DateTime day) {
    return tasks.where((task) {
      final d = task.date;
      return isSameDay(d, day);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB),

      appBar: AppBar(
        title: const Text("Calendar"),
        centerTitle: true,
        elevation: 0,
      ),

      body: StreamBuilder<List<TaskModel>>(
        stream: taskService.getTasks(),

        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final allTasks = snapshot.data!;
          final selectedTasks = _tasksForDay(allTasks, selectedDay);

          return Column(
            children: [

              // 📅 CALENDAR
              TableCalendar(
                focusedDay: selectedDay,
                firstDay: DateTime(2020),
                lastDay: DateTime(2100),

                selectedDayPredicate: (day) =>
                    isSameDay(day, selectedDay),

                onDaySelected: (selected, focused) {
                  setState(() => selectedDay = selected);
                },

                headerStyle: const HeaderStyle(
                  formatButtonVisible: false,
                  titleCentered: true,
                ),

                calendarBuilders: CalendarBuilders(
                  defaultBuilder: (context, day, _) {
                    final dayTasks = _tasksForDay(allTasks, day);

                    if (dayTasks.isEmpty) return null;

                    // 🔥 strongest priority wins for color
                    final hasHigh = dayTasks.any((t) => t.priority == "High");
                    final hasMedium = dayTasks.any((t) => t.priority == "Medium");

                    Color color = Colors.green;
                    if (hasHigh) {
                      color = Colors.red;
                    } else if (hasMedium) {
                      color = Colors.orange;
                    }

                    return Container(
                      margin: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.25),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          '${day.day}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  },
                ),

                calendarStyle: const CalendarStyle(
                  todayDecoration: BoxDecoration(
                    color: Colors.purple,
                    shape: BoxShape.circle,
                  ),
                  selectedDecoration: BoxDecoration(
                    color: Colors.deepPurple,
                    shape: BoxShape.circle,
                  ),
                ),
              ),

              const SizedBox(height: 10),

              // 📋 TASK LIST HEADER
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Text(
                      "Tasks (${selectedTasks.length})",
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 10),

              // 📋 TASK LIST
              Expanded(
                child: selectedTasks.isEmpty
                    ? const Center(
                        child: Text("No tasks for this day"),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(12),
                        itemCount: selectedTasks.length,

                        itemBuilder: (context, index) {
                          final task = selectedTasks[index];

                          return Container(
                            margin: const EdgeInsets.only(bottom: 12),

                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(18),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                )
                              ],
                            ),

                            child: ListTile(
                              contentPadding: const EdgeInsets.all(14),

                              leading: Container(
                                width: 12,
                                height: 60,
                                decoration: BoxDecoration(
                                  color: getPriorityColor(task.priority),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),

                              title: Text(
                                task.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 4),
                                  Text(task.category,
                                      style:
                                          const TextStyle(color: Colors.grey)),

                                  const SizedBox(height: 8),

                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: getStatusColor(task.status)
                                          .withOpacity(0.15),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      task.status,
                                      style: TextStyle(
                                        color: getStatusColor(task.status),
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              trailing: PopupMenuButton<String>(
  onSelected: (value) async {
    if (value == "edit") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => EditTaskScreen(task: task),
        ),
      );
    }

    if (value == "delete") {
      await taskService.deleteTask(task.taskId);
    }

    if (value == "pending" ||
        value == "in_progress" ||
        value == "completed") {
      await taskService.updateTaskStatus(task.taskId, value);
    }
  },

  itemBuilder: (context) => const [
    PopupMenuItem(
      value: "edit",
      child: Text("Edit Task"),
    ),
    PopupMenuItem(
      value: "delete",
      child: Text("Delete Task"),
    ),

    PopupMenuDivider(),

    PopupMenuItem(
      value: "pending",
      child: Text("Mark Pending"),
    ),
    PopupMenuItem(
      value: "in_progress",
      child: Text("Mark In Progress"),
    ),
    PopupMenuItem(
      value: "completed",
      child: Text("Mark Completed"),
    ),
  ],
),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}