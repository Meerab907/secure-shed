import 'package:flutter/material.dart';
import '../utils/routes.dart';

class IntroScreen extends StatelessWidget {
  const IntroScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF4B2E83);
    const secondary = Color(0xFF7A5CD6);
    const background = Color(0xFFF8F5FD);

    return Scaffold(
      backgroundColor: background,

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 20,
          ),

          child: Column(
            children: [

              const Spacer(),

              // 🔥 ICON CARD
              Container(
                padding: const EdgeInsets.all(35),

                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      primary,
                      secondary,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),

                  shape: BoxShape.circle,

                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.12),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),

                child: const Icon(
                  Icons.lock_clock_rounded,
                  size: 90,
                  color: Colors.white,
                ),
              ),

              const SizedBox(height: 45),

              // 🔥 TITLE
              const Text(
                "Welcome to Secure Shed",
                textAlign: TextAlign.center,

                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: primary,
                  height: 1.2,
                ),
              ),

              const SizedBox(height: 18),

              // 🔥 SUBTITLE
              Text(
                "Manage your daily tasks securely, stay organized, and never miss important reminders again.",
                textAlign: TextAlign.center,

                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey.shade700,
                  height: 1.5,
                ),
              ),

              const SizedBox(height: 50),

              // 🔥 FEATURE CARDS
              Row(
                children: [

                  Expanded(
                    child: _featureCard(
                      Icons.notifications_active_rounded,
                      "Smart Alerts",
                    ),
                  ),

                  const SizedBox(width: 14),

                  Expanded(
                    child: _featureCard(
                      Icons.security_rounded,
                      "Secure Access",
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),

              Row(
                children: [

                  Expanded(
                    child: _featureCard(
                      Icons.calendar_month_rounded,
                      "Task Planner",
                    ),
                  ),

                  const SizedBox(width: 14),

                  Expanded(
                    child: _featureCard(
                      Icons.fingerprint_rounded,
                      "Fingerprint Lock",
                    ),
                  ),
                ],
              ),

              const Spacer(),

              // 🔥 BUTTON
              SizedBox(
                width: double.infinity,
                height: 58,

                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(
                      context,
                      AppRoutes.login,
                    );
                  },

                  style: ElevatedButton.styleFrom(
                    backgroundColor: primary,

                    elevation: 4,

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),

                  child: const Text(
                    "Get Started",
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 15),
            ],
          ),
        ),
      ),
    );
  }

  static Widget _featureCard(
    IconData icon,
    String title,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 18,
        horizontal: 12,
      ),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius: BorderRadius.circular(18),

        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),

      child: Column(
        children: [
          Icon(
            icon,
            size: 34,
            color: const Color(0xFF4B2E83),
          ),

          const SizedBox(height: 10),

          Text(
            title,
            textAlign: TextAlign.center,

            style: const TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}