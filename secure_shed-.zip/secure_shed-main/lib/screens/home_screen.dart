import 'package:flutter/material.dart';
import '../utils/routes.dart';
import 'drawer_widget.dart';

import '../models/task_model.dart';
import '../services/task_service.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const primaryColor = Color(0xFF4B2E83);
    const backgroundColor = Color(0xFFF8EAF6);

    return Scaffold(
      backgroundColor: backgroundColor,
      drawer: const DrawerWidget(),

      appBar: AppBar(
        backgroundColor: primaryColor,
        title: const Text(
          "Secure Shed",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),

      body: StreamBuilder<List<TaskModel>>(
        stream: TaskService().getTasks(),
        builder: (context, snapshot) {

          final tasks = snapshot.data ?? [];

          final total = tasks.length;
          final completed =
              tasks.where((t) => t.status == "Completed").length;
          final pending =
              tasks.where((t) => t.status != "Completed").length;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // 🔥 HEADER
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF4B2E83),
                        Color(0xFF6A4CB8),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Good Day 👋",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        "Manage your tasks efficiently",
                        style: TextStyle(color: Colors.white70),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // 🔥 STATS ROW (LIVE DATA)
                Row(
                  children: [
                    _statCard(
                      title: "Total",
                      value: total.toString(),
                      color: Colors.blue,
                      onTap: () =>
                          Navigator.pushNamed(context, AppRoutes.displayTask),
                    ),
                    const SizedBox(width: 10),
                    _statCard(
                      title: "Pending",
                      value: pending.toString(),
                      color: Colors.orange,
                      onTap: () =>
                          Navigator.pushNamed(context, AppRoutes.todayTasks),
                    ),
                    const SizedBox(width: 10),
                    _statCard(
                      title: "Done",
                      value: completed.toString(),
                      color: Colors.green,
                      onTap: () =>
                          Navigator.pushNamed(context, AppRoutes.displayTask),
                    ),
                  ],
                ),

                const SizedBox(height: 25),

                const Text(
                  "Quick Actions",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: primaryColor,
                  ),
                ),

                const SizedBox(height: 15),

                // 🔥 GRID MENU
                Expanded(
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    children: [
                      _menuCard(
                        context,
                        "Create Task",
                        Icons.add,
                        AppRoutes.createTask,
                      ),
                      _menuCard(
                        context,
                        "All Tasks",
                        Icons.list,
                        AppRoutes.displayTask,
                      ),
                      _menuCard(
                        context,
                        "Calendar",
                        Icons.calendar_month,
                        AppRoutes.calendar,
                      ),
                      _menuCard(
                        context,
                        "Today",
                        Icons.today,
                        AppRoutes.todayTasks,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // 🔥 MENU CARD
  static Widget _menuCard(
    BuildContext context,
    String title,
    IconData icon,
    String route,
  ) {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, route),
      borderRadius: BorderRadius.circular(18),

      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 10,
            ),
          ],
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: const Color(0xFF4B2E83)),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  // 🔥 STAT CARD (CLICKABLE + LIVE COUNT)
  Widget _statCard({
    required String title,
    required String value,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 10,
              ),
            ],
          ),
          child: Column(
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              
            ],
          ),
        ),
      ),
    );
  }
}