import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/task_service.dart';

class ProfileScreen extends StatelessWidget {
  ProfileScreen({super.key});

  final taskService = TaskService();

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    const Color primaryColor = Color(0xFF4B2E83);
    const Color backgroundColor = Color(0xFFF8EAF6);

    return Scaffold(
      backgroundColor: backgroundColor,

      appBar: AppBar(
        title: const Text(
          "Profile",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
      ),

      body: StreamBuilder(
        stream: taskService.getTasks(),

        builder: (context, snapshot) {

          final tasks = snapshot.data ?? [];

          final completed =
              tasks.where((t) => t.status == "Completed").length;

          final pending =
              tasks.where((t) => t.status != "Completed").length;

          final total = tasks.length;

          double progress = 0;

          if (total > 0) {
            progress = completed / total;
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [

                //////////////////////////////////////////////////////
                // PROFILE HEADER
                //////////////////////////////////////////////////////

                Container(
                  padding: const EdgeInsets.all(20),

                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF4B2E83),
                        Color(0xFF6A4CB8),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),

                    borderRadius: BorderRadius.circular(24),

                    boxShadow: [
                      BoxShadow(
                        color: primaryColor.withOpacity(0.25),
                        blurRadius: 12,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),

                  child: Row(
                    children: [

                      const CircleAvatar(
                        radius: 38,
                        backgroundColor: Colors.white,

                        child: Icon(
                          Icons.person,
                          size: 45,
                          color: primaryColor,
                        ),
                      ),

                      const SizedBox(width: 18),

                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,

                          children: [

                            Text(
                              user?.displayName ?? "Secure Shed User",

                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            const SizedBox(height: 6),

                            Text(
                              user?.email ?? "No Email",

                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 30),

                //////////////////////////////////////////////////////
                // TASK OVERVIEW TITLE
                //////////////////////////////////////////////////////

                const Text(
                  "Task Overview",

                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: primaryColor,
                  ),
                ),

                const SizedBox(height: 20),

                //////////////////////////////////////////////////////
                // STATS CARDS
                //////////////////////////////////////////////////////

                Row(
                  children: [

                    Expanded(
                      child: _buildStatCard(
                        title: "Completed",
                        value: completed.toString(),
                        icon: Icons.check_circle,
                        color: Colors.green,
                      ),
                    ),

                    const SizedBox(width: 16),

                    Expanded(
                      child: _buildStatCard(
                        title: "Pending",
                        value: pending.toString(),
                        icon: Icons.pending_actions,
                        color: Colors.orange,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                //////////////////////////////////////////////////////
                // PROGRESS SECTION
                //////////////////////////////////////////////////////

                Container(
                  padding: const EdgeInsets.all(20),

                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),

                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                      ),
                    ],
                  ),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [

                      const Text(
                        "Completion Progress",

                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: primaryColor,
                        ),
                      ),

                      const SizedBox(height: 20),

                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),

                        child: LinearProgressIndicator(
                          value: progress,
                          minHeight: 12,
                          backgroundColor: Colors.grey.shade300,
                          valueColor: const AlwaysStoppedAnimation(
                            Colors.green,
                          ),
                        ),
                      ),

                      const SizedBox(height: 12),

                      Text(
                        "${(progress * 100).toStringAsFixed(0)}% Tasks Completed",

                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                //////////////////////////////////////////////////////
                // ACTIVITY PLACEHOLDER
                //////////////////////////////////////////////////////

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),

                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),

                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                      ),
                    ],
                  ),

                  child: const Column(
                    children: [

                      Icon(
                        Icons.bar_chart,
                        size: 60,
                        color: primaryColor,
                      ),

                      SizedBox(height: 16),

                      Text(
                        "Weekly Activity Graph",

                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: primaryColor,
                        ),
                      ),

                      SizedBox(height: 10),

                      Text(
                        "Graph visualization can be added here later.",
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  //////////////////////////////////////////////////////
  // STAT CARD
  //////////////////////////////////////////////////////

  static Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),

        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
          ),
        ],
      ),

      child: Column(
        children: [

          Icon(
            icon,
            color: color,
            size: 40,
          ),

          const SizedBox(height: 14),

          Text(
            value,

            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),

          const SizedBox(height: 6),

          Text(
            title,

            style: const TextStyle(
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}