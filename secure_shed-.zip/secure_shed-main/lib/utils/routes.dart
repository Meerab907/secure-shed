class AppRoutes {
  static const loading = '/';
  static const getStarted = '/get-started';
  static const intro = '/intro';
  static const login = '/login';
  static const signup = '/signup';

  static const forgotPassword = '/forgot-password';
  static const verificationCode = '/verification-code';
  static const resetPassword = '/reset-password';

  static const identity1 = '/identity-1';
  static const identity2 = '/identity-2';
  static const identity3 = '/identity-3';
  static const identity4 = '/identity-4';
  static const identity5 = '/identity-5';

  static const securityIntro = '/security-intro';
  static const face = '/face';
  static const fingerprint = '/fingerprint';
  static const pin = '/pin';

  static const home = '/home';
  static const calendar = '/calendar';
  static const profile = '/profile';
  static const createTask = '/create-task';
  static const displayTask = '/display-task';
  static const reschedule = '/reschedule';
  static const addMeeting = '/add-meeting';
  static const category = '/category';
  static const todayTasks = '/today-tasks';
  static const settings = '/settings';
  static const String editProfile = '/editProfile';
}