class StatusHelper {
  static String getStatus({
    required DateTime start,
    required DateTime end,
  }) {
    final now = DateTime.now();

    if (now.isBefore(start)) {
      return "Upcoming";
    }

    if (now.isAfter(start) && now.isBefore(end)) {
      return "In Progress";
    }

    return "Completed";
  }
}